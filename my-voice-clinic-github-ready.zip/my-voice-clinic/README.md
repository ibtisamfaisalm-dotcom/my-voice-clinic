# My Voice Clinic

Static responsive website for My Voice Clinic by Ibtisam, MASLP.

## Structure
- index.html — website
- assets/clinic-office.png — supplied clinic/brand image
- assets/logo.svg — scalable logo
- assets/favicon.svg — browser icon

## GitHub Pages
Create a repository called `my-voice-clinic`, upload these files, then enable Pages from Settings → Pages using the `main` branch.

GitHub Pages can later use a custom domain such as `www.myvoiceclinic.com`.

## Before going live
Replace placeholder contact/social details. Add your correct professional registration information only. Do not describe the clinic or website as RCI-approved unless you have specific documentation for that claim.

The contact form is currently front-end only. Connect it to a secure form/booking service before collecting real client or clinical information.
